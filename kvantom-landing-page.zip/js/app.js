const header = document.querySelector("[data-js-header]");
const headerScrolledClass =
  header.getAttribute("data-js-header-scrolled") || "";
const headerOpenedClass = header.getAttribute("data-js-header-opened") || "";
const headerToggle = document.querySelector("[data-js-header-toggle]");
const headerToggleActiveClass =
  headerToggle.getAttribute("data-js-header-toggle-active") || "";

function animationHeader(item, currentPosition) {
  if (!item) {
    return;
  }
  currentPosition > 96
    ? item.classList.add(headerScrolledClass)
    : item.classList.remove(headerScrolledClass);
}

animationHeader(
  header,
  window.pageYOffset || document.documentElement.scrollTop
);

window.addEventListener("scroll", function () {
  const scrolled = window.pageYOffset || document.documentElement.scrollTop;
  animationHeader(header, scrolled);
});

headerToggle &&
  header &&
  (headerToggle.onclick = (e) => {
    header.classList.toggle(headerOpenedClass);
    e.target.classList.toggle(headerToggleActiveClass);
  });

var headerLinks = document.querySelectorAll(".c-header__menu-link");
headerLinks.forEach(function (headerLink) {
  headerLink.addEventListener("click", function () {
    header.classList.remove("c-header--opened");
    headerToggle.classList.remove("c-header__burger--active");
  });
});

//intro slider

const fraction = document.getElementById("fraction-about");
const all = document.getElementById("swiper-all-slides-number");
const slides = document.querySelectorAll(".about-slide");
const slideCount = slides.length;
fraction.textContent = `1`;
all.textContent = `${slideCount}`;

let swiper1 = new Swiper(".c-slider", {
  spaceBetween: 30,
  hashNavigation: {
    watchState: true,
  },

  navigation: {
    prevEl: ".swiper-custom-prev",
    nextEl: ".swiper-custom-next",
  },

  pagination: {
    el: ".c-slider__pagination",
    clickable: true,
    type: "bullets",
  },
  on: {
    slideChange: () => {
      fraction.textContent = `${swiper1.realIndex + 1} `;
      all.textContent = `${slideCount}`;
    },
  },
});

//testimonial

let swiper2 = new Swiper(".c-testimonial__slider", {
  watchSlidesProgress: true,
  slidesPerView: 2,
  spaceBetween: 30,
  navigation: {
    nextEl: ".c-testimonial__custom-next",
    prevEl: ".c-testimonial__custom-prev",
  },
  paginationClickable: true,
  pagination: {
    el: ".c-testimonial__pagination",
    clickable: true,
    type: "bullets",
  },
  breakpoints: {
    320: {
      slidesPerView: 1,
    },
    480: {
      slidesPerView: 1,
    },
    640: {
      slidesPerView: 2,
    },
  },
});

// works counter

var gallery = new Swiper(".left-side-slider-gallery", {
  slidesPerView: 1,
  pagination: {
    el: ".jail-app-left-side-fractions",
    type: "custom",
    renderCustom: function (swiper, current, total) {
      return current + "/" + (total - 1);
    },
  },
});

let galleryThumbs = new Swiper(".gallery-thumbs", {
    centeredSlidesBounds: !0,
    centeredSlides: !0,
    slidesPerView: 3,
    spaceBetween: 16,
    watchOverflow: !0,
    watchSlidesVisibility: !0,
    watchSlidesProgress: !0,
    direction: "horizontal",
    breakpoints: {
      992: {
        direction: "vertical",
        slidesPerView: 5,
      },
      768: {
        direction: "horizontal",
        slidesPerView: 5,
      },
      560: {
        slidesPerView: 5,
      },
    },
  }),
  galleryMain = new Swiper(".gallery-main", {
    watchOverflow: !0,
    watchSlidesVisibility: !0,
    watchSlidesProgress: !0,
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
    effect: "fade",
    fadeEffect: { crossFade: !0 },
    thumbs: { swiper: galleryThumbs },
  }),
  galleryText = new Swiper(".gallery-text", {
    slidesPerView: 1,
    centeredSlides: !0,
    watchOverflow: !0,
  });
(galleryText.controller.control = galleryMain),
  (galleryMain.controller.control = galleryText);

//scroll up

var scrollToTopBtn = document.querySelector(".scroll-up");
var rootElement = document.documentElement;

function handleScroll() {
  var scrollTotal = rootElement.scrollHeight - rootElement.clientHeight;
  if (rootElement.scrollTop / scrollTotal > 0.8) {
    scrollToTopBtn.classList.add("scroll-up--show");
  } else {
    scrollToTopBtn.classList.remove("scroll-up--show");
  }
}

function scrollToTop() {
  // Scroll to top logic
  rootElement.scrollTo({
    top: 0,
    behavior: "smooth",
  });
}
scrollToTopBtn.addEventListener("click", scrollToTop);
document.addEventListener("scroll", handleScroll);

let needToPlayAnimation = true;
let i = 1;
let timeout = 700;
$(window).scroll(function () {
  var howWorkTop = $("#how-work").position().top;
  if ($(window).scrollTop() >= howWorkTop - 300) {
    if (needToPlayAnimation) {
      $(".c-steps-work__list-item-number").each(function () {
        setTimeout(function () {
          $(
            ".c-steps-work__list-item:nth-of-type(" +
              i +
              ") .c-steps-work__list-item-number"
          ).addClass("c-steps-work__list-item-number--highlighted");
          i += 1;
        }, timeout);
        timeout += 700;
      });
      needToPlayAnimation = false;
    }
  }
});

AOS.init();

// popups

$(document).on("click", ".show-sontact-us", function () {
  let service = $(this).data("service");
  $(".popup__select").val(service);
});

$(".show-sontact-us").magnificPopup({
  items: {
    src: ".popup--contact-us",
  },
  type: "inline",
  mainClass: "my-mfp-slide-bottom",
  fixedContentPos: true,
});

$(".show-thank-you").magnificPopup({
  items: {
    src: ".popup--thank-you",
  },
  type: "inline",
  mainClass: "my-mfp-slide-bottom",
  fixedContentPos: true,
});

// send message on email Ajax
$("#main-form").submit(function () {
  $.ajax({
    type: "POST",
    url: "mail.php",
    data: $(this).serialize(),
  }).done(function () {
    $(this).find("input").val("");

    $.magnificPopup.open({
      items: {
        src: "#thankyou",
      },
      mainClass: "mfp-letter",
    });
  });
  return false;
});
